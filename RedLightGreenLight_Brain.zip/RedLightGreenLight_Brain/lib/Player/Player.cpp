#include "Player.h"
#include <Arduino.h>

Player* pPlayerInstance;  // Global pointer to Player instance

Player::Player() {

}

void Player::begin() {
    _id = 20;
    _status = IDLE;
}

void Player::setStatus(PlayerStatus status) {
    _status = status;
}

PlayerStatus Player::getStatus() {
    return _status;
}

int Player::getId() {
    return _id;
}
